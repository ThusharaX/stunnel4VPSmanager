<?php

// MySQL Hostname / Server (for eg: 'localhost')
$sql_host = 'localhost';


// MySQL Database Name
$sql_name = 'freessh';


// MySQL Database User
$sql_user = 'root';


// MySQL Database Password
$sql_pass = '';


//Senha do admin
$passw = "12345";

