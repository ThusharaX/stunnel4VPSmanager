<?php
//by twossh


if(isset($_SESSION['id'])){
	
	echo 1;
	
	return;
}


if(serves($_POST['server']) == "notserver"){
	
	echo "Servidor não encontrado!!!";
	return;
}else{
	
	include('Net/SSH2.php');
	
	$server = serves($_POST['server']);
	
$ssh = new Net_SSH2(''.$server['ip']);
if (!$ssh->login('root', ''.$server['pass'])) {
    exit('Login Failed');
}
	
	
$nome = "u-".chr(rand(65,90)) . chr(rand(65,90)) . chr(rand(65,90)) . chr(rand(65,90)) . chr(rand(65,90));
$senha = "s-".rand(1111,99999);

	
	$log = $ssh->exec("useradd ".$nome);
	
	
	if($log != null){

echo "<small style='color: white'>Conta <b style='color: red;'>$nome</b> já existe!!!</small>";




}else {

 $ssh->setTimeout(1);
$ssh->read('username@username:~$');
$ssh->write("passwd $nome \n"); 
$ssh->read('username@username:~$');
$ssh->write($senha."\n");
$ssh->read('username@username:~$');
$ssh->write($senha."\n");
$ssh->read('username@username:~$');
$ssh->write("limite $nome 1 \n");
$ssh->read(); 


}

}





echo "<h3>Login criado com sucesso!!!</h3>";
echo "<b>IP / Host:</b>  $server[ip]";
echo "<br>";
echo "<b>Porta SSH:</b> 22, 443";
echo "<br>";
echo "<b>Porta Proxy:</b> 80";
echo "<br>";
echo "<b>Usuário:</b> ".$nome;
echo "<br>";
echo "<b>Senha:</b> ".$senha;
echo "<br>";




$query = $conn->query("INSERT INTO `sshfree`(nome, senha, tempo, ip, iphost) VALUES ('$nome','$senha',NOW(),'$ip','$_POST[server]')");


$query1 = $conn->query("SELECT * FROM `sshfree` WHERE nome='$nome'");
$fetch = $query1->fetch_array(MYSQLI_ASSOC);


$_SESSION['id'] = $fetch['id'];
$_SESSION['id'] = $fetch['id'];
$cookie_name = "id";




